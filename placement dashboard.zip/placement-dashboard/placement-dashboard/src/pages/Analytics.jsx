import { useMemo } from "react";
import {
  ResponsiveContainer, LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend,
} from "recharts";
import { useData } from "../context/DataContext.jsx";
import { useApplications } from "../context/ApplicationsContext.jsx";
import ChartCard from "../components/ChartCard.jsx";
import Loader from "../components/Loader.jsx";
import ErrorMessage from "../components/ErrorMessage.jsx";
import { STATUSES } from "../constants.js";

const STATUS_COLORS = {
  Applied: "#3b82f6",
  "Under Review": "#f59e0b",
  Shortlisted: "#a855f7",
  "Interview Scheduled": "#6366f1",
  Selected: "#22c55e",
  Rejected: "#ef4444",
  Withdrawn: "#9ca3af",
};

const PIPELINE = ["Applied", "Under Review", "Shortlisted", "Interview Scheduled", "Selected"];

function Analytics() {
  const { stats, loading, error, retry } = useData();
  const { applications } = useApplications();

  // Applications grouped by their current status
  const statusData = useMemo(
    () =>
      STATUSES.map((status) => ({
        name: status,
        value: applications.filter((a) => a.status === status).length,
      })).filter((item) => item.value > 0),
    [applications]
  );

  // How many applications ever reached each stage
  const pipelineData = useMemo(
    () =>
      PIPELINE.map((stage) => ({
        stage,
        applications: applications.filter((a) => a.history.some((h) => h.status === stage)).length,
      })),
    [applications]
  );

  const yearlyData = useMemo(
    () => (stats ? stats.yearly.map((y) => ({ ...y, percent: Math.round((y.placed / y.total) * 100) })) : []),
    [stats]
  );

  return (
    <div>
      <div className="page-header">
        <h1>Analytics</h1>
        <p className="muted">Your application progress and campus placement statistics.</p>
      </div>

      <h2 className="section-heading">My applications</h2>
      {applications.length === 0 ? (
        <p className="card muted">Apply to some openings to see your own charts here.</p>
      ) : (
        <div className="chart-grid">
          <ChartCard title="Applications by status" subtitle="Current status of each application">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={statusData} dataKey="value" nameKey="name" innerRadius={55} outerRadius={95} paddingAngle={2}>
                  {statusData.map((entry) => (
                    <Cell key={entry.name} fill={STATUS_COLORS[entry.name]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </ChartCard>

          <ChartCard title="Application pipeline" subtitle="How many applications reached each stage">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={pipelineData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="stage" tick={{ fontSize: 11 }} interval={0} />
                <YAxis allowDecimals={false} />
                <Tooltip />
                <Bar dataKey="applications" fill="#4f46e5" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>
      )}

      <h2 className="section-heading">Campus placement statistics (sample data)</h2>
      {loading && <Loader text="Loading statistics..." />}
      {error && <ErrorMessage message={error} onRetry={retry} />}

      {stats && (
        <div className="chart-grid">
          <ChartCard title="Placement trend" subtitle="Percentage of students placed each year">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={yearlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="year" />
                <YAxis unit="%" domain={[50, 100]} />
                <Tooltip />
                <Line type="monotone" dataKey="percent" name="Placed (%)" stroke="#4f46e5" strokeWidth={3} dot={{ r: 5 }} />
              </LineChart>
            </ResponsiveContainer>
          </ChartCard>

          <ChartCard title="Package distribution" subtitle="Number of students in each package band">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.packageBands}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="band" tick={{ fontSize: 11 }} interval={0} />
                <YAxis />
                <Tooltip />
                <Bar dataKey="students" fill="#0ea5e9" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>

          <ChartCard title="Top recruiters" subtitle="Offers made by company">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.topRecruiters} layout="vertical" margin={{ left: 20 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                <XAxis type="number" />
                <YAxis type="category" dataKey="company" width={80} />
                <Tooltip />
                <Bar dataKey="offers" fill="#14b8a6" radius={[0, 6, 6, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>

          <ChartCard title="Department-wise placement" subtitle="Percentage of students placed">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.departments}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="department" tick={{ fontSize: 11 }} interval={0} />
                <YAxis unit="%" domain={[0, 100]} />
                <Tooltip />
                <Bar dataKey="percent" name="Placed (%)" fill="#f59e0b" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>
      )}
    </div>
  );
}

export default Analytics;
