import { useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import FormField from "../components/FormField.jsx";
import PasswordInput from "../components/PasswordInput.jsx";
import { validateLogin } from "../utils/validators.js";
import { DEMO_EMAIL, DEMO_PASSWORD } from "../constants.js";

function Login() {
  const { login } = useAuth();
  const [values, setValues] = useState({ email: "", password: "" });
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState("");
  const [loading, setLoading] = useState(false);

  function handleChange(event) {
    const { name, value } = event.target;
    setValues((current) => ({ ...current, [name]: value }));
    if (errors[name]) setErrors((current) => ({ ...current, [name]: "" }));
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setFormError("");

    const validation = validateLogin(values);
    setErrors(validation);
    if (Object.keys(validation).length > 0) return;

    setLoading(true);
    try {
      // On success the router redirects to the dashboard automatically
      await login(values.email, values.password);
    } catch (err) {
      setFormError(err.message);
      setLoading(false);
    }
  }

  function fillDemo() {
    setValues({ email: DEMO_EMAIL, password: DEMO_PASSWORD });
    setErrors({});
    setFormError("");
  }

  return (
    <div className="auth-page">
      <div className="auth-side">
        <h1>Student Placement Dashboard</h1>
        <p>Track openings, applications, interviews and campus placement statistics in one place.</p>
      </div>

      <div className="auth-form-wrap">
        <form className="auth-card" onSubmit={handleSubmit} noValidate>
          <h2>Welcome back</h2>
          <p className="muted">Log in to continue.</p>

          {formError && <p className="form-error" role="alert">{formError}</p>}

          <FormField id="email" label="Email" error={errors.email}>
            <input
              id="email"
              name="email"
              type="email"
              className={`input ${errors.email ? "invalid" : ""}`}
              value={values.email}
              onChange={handleChange}
              placeholder="you@college.edu"
              autoComplete="email"
              aria-invalid={errors.email ? "true" : "false"}
              aria-describedby={errors.email ? "email-error" : undefined}
            />
          </FormField>

          <FormField id="password" label="Password" error={errors.password}>
            <PasswordInput
              id="password"
              name="password"
              value={values.password}
              onChange={handleChange}
              placeholder="Your password"
              hasError={Boolean(errors.password)}
              autoComplete="current-password"
            />
          </FormField>

          <button type="submit" className="btn btn-primary btn-block" disabled={loading}>
            {loading ? "Logging in..." : "Log in"}
          </button>

          <div className="demo-box">
            <p><strong>Demo account</strong></p>
            <p className="small">Email: {DEMO_EMAIL}<br />Password: {DEMO_PASSWORD}</p>
            <button type="button" className="btn btn-outline btn-sm" onClick={fillDemo}>
              Fill demo login
            </button>
          </div>

          <p className="auth-switch">
            New here? <Link to="/register">Create an account</Link>
          </p>
        </form>
      </div>
    </div>
  );
}

export default Login;
