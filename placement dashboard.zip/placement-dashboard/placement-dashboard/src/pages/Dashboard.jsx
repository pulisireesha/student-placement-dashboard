import { useMemo } from "react";
import { Link } from "react-router-dom";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { useAuth } from "../context/AuthContext.jsx";
import { useData } from "../context/DataContext.jsx";
import { useApplications } from "../context/ApplicationsContext.jsx";
import StatCard from "../components/StatCard.jsx";
import StatusBadge from "../components/StatusBadge.jsx";
import CompanyLogo from "../components/CompanyLogo.jsx";
import Loader from "../components/Loader.jsx";
import ErrorMessage from "../components/ErrorMessage.jsx";
import { firstName } from "../utils/format.js";
import { formatDate, formatDateTime, deadlineLabel, timeAgo } from "../utils/dates.js";

function Dashboard() {
  const { user } = useAuth();
  const { jobs, announcements, stats, loading, error, retry } = useData();
  const { applications, counts, hasApplied } = useApplications();

  const upcomingInterviews = useMemo(
    () =>
      applications
        .filter((a) => a.status === "Interview Scheduled" && a.interviewDate)
        .sort((a, b) => new Date(a.interviewDate) - new Date(b.interviewDate)),
    [applications]
  );

  const recentApplications = useMemo(
    () => [...applications].sort((a, b) => new Date(b.appliedAt) - new Date(a.appliedAt)).slice(0, 5),
    [applications]
  );

  const upcomingDeadlines = useMemo(
    () =>
      jobs
        .filter((job) => new Date(job.deadline) > new Date() && !hasApplied(job.id))
        .sort((a, b) => new Date(a.deadline) - new Date(b.deadline))
        .slice(0, 5),
    [jobs, hasApplied]
  );

  return (
    <div>
      <div className="page-header">
        <h1>Welcome back, {firstName(user.name)}!</h1>
        <p className="muted">Here is a summary of your placement activity.</p>
      </div>

      <section className="stats-grid" aria-label="Application summary">
        <StatCard icon="📨" label="Total applications" value={counts.total} tone="blue" />
        <StatCard icon="⏳" label="In progress" value={counts.inProgress} tone="amber" />
        <StatCard icon="🗓️" label="Interviews scheduled" value={counts.interviews} tone="indigo" />
        <StatCard icon="🏆" label="Selected" value={counts.selected} tone="green" />
        <StatCard icon="❌" label="Rejected" value={counts.rejected} tone="red" />
      </section>

      {loading && <Loader text="Loading placement data..." />}
      {error && <ErrorMessage message={error} onRetry={retry} />}

      <div className="two-col">
        <section className="card">
          <h2 className="card-title">Upcoming interviews</h2>
          {upcomingInterviews.length === 0 ? (
            <p className="muted">No interviews scheduled yet.</p>
          ) : (
            <ul className="list">
              {upcomingInterviews.map((a) => (
                <li key={a.id} className="list-item">
                  <CompanyLogo name={a.company} size={38} />
                  <div>
                    <p><strong>{a.company}</strong> · {a.title}</p>
                    <p className="muted small">{a.interviewRound} · {formatDateTime(a.interviewDate)}</p>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="card">
          <h2 className="card-title">Upcoming deadlines</h2>
          {upcomingDeadlines.length === 0 ? (
            <p className="muted">{loading ? "Loading..." : "No open deadlines."}</p>
          ) : (
            <ul className="list">
              {upcomingDeadlines.map((job) => (
                <li key={job.id} className="list-item">
                  <CompanyLogo name={job.company} size={38} />
                  <div>
                    <p><strong>{job.title}</strong> · {job.company}</p>
                    <p className="muted small">{formatDate(job.deadline)} · {deadlineLabel(job.deadline)}</p>
                  </div>
                </li>
              ))}
            </ul>
          )}
          <Link to="/jobs" className="card-link">Browse all opportunities</Link>
        </section>

        <section className="card">
          <h2 className="card-title">Recent applications</h2>
          {recentApplications.length === 0 ? (
            <p className="muted">You have not applied anywhere yet.</p>
          ) : (
            <ul className="list">
              {recentApplications.map((a) => (
                <li key={a.id} className="list-item">
                  <CompanyLogo name={a.company} size={38} />
                  <div className="grow">
                    <p><strong>{a.company}</strong> · {a.title}</p>
                    <p className="muted small">Applied {timeAgo(a.appliedAt)}</p>
                  </div>
                  <StatusBadge status={a.status} />
                </li>
              ))}
            </ul>
          )}
          <Link to="/applications" className="card-link">View all applications</Link>
        </section>

        <section className="card">
          <h2 className="card-title">Latest announcements</h2>
          {announcements.length === 0 ? (
            <p className="muted">{loading ? "Loading..." : "No announcements."}</p>
          ) : (
            <ul className="list">
              {announcements.slice(0, 3).map((item) => (
                <li key={item.id} className="announcement">
                  <p><strong>{item.title}</strong></p>
                  <p className="small">{item.message}</p>
                  <p className="muted small">{timeAgo(item.date)}</p>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      {stats && (
        <section className="card">
          <h2 className="card-title">Placement statistics</h2>
          <p className="muted small">Sample campus data for demonstration.</p>
          <div className="highlight-grid">
            <div><p className="stat-value">{stats.highlights.placementRate}%</p><p className="stat-label">Placement rate</p></div>
            <div><p className="stat-value">{stats.highlights.highestPackage} LPA</p><p className="stat-label">Highest package</p></div>
            <div><p className="stat-value">{stats.highlights.averagePackage} LPA</p><p className="stat-label">Average package</p></div>
            <div><p className="stat-value">{stats.highlights.companiesVisited}</p><p className="stat-label">Companies visited</p></div>
          </div>
          <div className="chart-box small-chart">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.yearly}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="year" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="placed" name="Students placed" fill="#4f46e5" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <Link to="/analytics" className="card-link">See full analytics</Link>
        </section>
      )}
    </div>
  );
}

export default Dashboard;
