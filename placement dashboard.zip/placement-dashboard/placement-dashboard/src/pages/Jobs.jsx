import { useMemo, useState } from "react";
import { useAuth } from "../context/AuthContext.jsx";
import { useData } from "../context/DataContext.jsx";
import { useApplications } from "../context/ApplicationsContext.jsx";
import JobCard from "../components/JobCard.jsx";
import ApplyModal from "../components/ApplyModal.jsx";
import Loader from "../components/Loader.jsx";
import ErrorMessage from "../components/ErrorMessage.jsx";
import EmptyState from "../components/EmptyState.jsx";
import { daysUntil } from "../utils/dates.js";

const INITIAL_FILTERS = {
  search: "", company: "", location: "", type: "",
  packageRange: "", skill: "", eligibility: "", deadline: "",
};

const PACKAGE_RANGES = {
  low: { label: "Below 4 LPA", test: (p) => p < 4 },
  mid: { label: "4 - 6 LPA", test: (p) => p >= 4 && p < 6 },
  high: { label: "6 - 10 LPA", test: (p) => p >= 6 && p < 10 },
  top: { label: "10 LPA and above", test: (p) => p >= 10 },
};

const DEADLINE_OPTIONS = [
  { value: "7", label: "Within 7 days" },
  { value: "14", label: "Within 14 days" },
  { value: "30", label: "Within 30 days" },
];

const unique = (list) => [...new Set(list)].sort();

function Jobs() {
  const { user } = useAuth();
  const { jobs, loading, error, retry } = useData();
  const { hasApplied, applyToJob } = useApplications();

  const [filters, setFilters] = useState(INITIAL_FILTERS);
  const [selectedJob, setSelectedJob] = useState(null);

  function handleChange(event) {
    const { name, value } = event.target;
    setFilters((current) => ({ ...current, [name]: value }));
  }

  // Dropdown options come from the data, so they always match the jobs
  const options = useMemo(
    () => ({
      companies: unique(jobs.map((j) => j.company)),
      locations: unique(jobs.map((j) => j.location)),
      types: unique(jobs.map((j) => j.type)),
      skills: unique(jobs.flatMap((j) => j.skills)),
      eligibility: unique(jobs.map((j) => j.eligibility)),
    }),
    [jobs]
  );

  const filteredJobs = useMemo(() => {
    const term = filters.search.trim().toLowerCase();

    return jobs.filter((job) => {
      if (term) {
        const haystack = [job.company, job.title, ...job.skills].join(" ").toLowerCase();
        if (!haystack.includes(term)) return false;
      }
      if (filters.company && job.company !== filters.company) return false;
      if (filters.location && job.location !== filters.location) return false;
      if (filters.type && job.type !== filters.type) return false;
      if (filters.skill && !job.skills.includes(filters.skill)) return false;
      if (filters.eligibility && job.eligibility !== filters.eligibility) return false;
      if (filters.packageRange && !PACKAGE_RANGES[filters.packageRange].test(job.packageLpa)) return false;
      if (filters.deadline) {
        const days = daysUntil(job.deadline);
        if (days < 0 || days > Number(filters.deadline)) return false;
      }
      return true;
    });
  }, [jobs, filters]);

  const hasActiveFilters = Object.values(filters).some((value) => value !== "");

  return (
    <div>
      <div className="page-header">
        <h1>Placement opportunities</h1>
        <p className="muted">Search and filter openings, then apply.</p>
      </div>

      <p className="banner">
        Demo data: these companies and openings are sample entries for this project, not real current vacancies.
      </p>

      <section className="card filters" aria-label="Search and filters">
        <div className="field search-field">
          <label htmlFor="search">Search</label>
          <input
            id="search"
            name="search"
            type="search"
            className="input"
            placeholder="Company, job title or skill"
            value={filters.search}
            onChange={handleChange}
          />
        </div>

        <div className="filter-grid">
          <div className="field">
            <label htmlFor="company">Company</label>
            <select id="company" name="company" className="input" value={filters.company} onChange={handleChange}>
              <option value="">All companies</option>
              {options.companies.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div className="field">
            <label htmlFor="location">Location</label>
            <select id="location" name="location" className="input" value={filters.location} onChange={handleChange}>
              <option value="">All locations</option>
              {options.locations.map((l) => <option key={l} value={l}>{l}</option>)}
            </select>
          </div>
          <div className="field">
            <label htmlFor="type">Job type</label>
            <select id="type" name="type" className="input" value={filters.type} onChange={handleChange}>
              <option value="">All types</option>
              {options.types.map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
          <div className="field">
            <label htmlFor="packageRange">Package</label>
            <select id="packageRange" name="packageRange" className="input" value={filters.packageRange} onChange={handleChange}>
              <option value="">Any package</option>
              {Object.entries(PACKAGE_RANGES).map(([key, range]) => (
                <option key={key} value={key}>{range.label}</option>
              ))}
            </select>
          </div>
          <div className="field">
            <label htmlFor="skill">Skill</label>
            <select id="skill" name="skill" className="input" value={filters.skill} onChange={handleChange}>
              <option value="">Any skill</option>
              {options.skills.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div className="field">
            <label htmlFor="eligibility">Eligibility</label>
            <select id="eligibility" name="eligibility" className="input" value={filters.eligibility} onChange={handleChange}>
              <option value="">Any eligibility</option>
              {options.eligibility.map((e) => <option key={e} value={e}>{e}</option>)}
            </select>
          </div>
          <div className="field">
            <label htmlFor="deadline">Application deadline</label>
            <select id="deadline" name="deadline" className="input" value={filters.deadline} onChange={handleChange}>
              <option value="">Any deadline</option>
              {DEADLINE_OPTIONS.map((d) => <option key={d.value} value={d.value}>{d.label}</option>)}
            </select>
          </div>
          <div className="field clear-field">
            <button
              type="button"
              className="btn btn-outline"
              onClick={() => setFilters(INITIAL_FILTERS)}
              disabled={!hasActiveFilters}
            >
              Clear filters
            </button>
          </div>
        </div>
      </section>

      {loading && <Loader text="Loading opportunities..." />}
      {error && <ErrorMessage message={error} onRetry={retry} />}

      {!loading && !error && (
        <>
          <p className="result-count" role="status">
            Showing {filteredJobs.length} of {jobs.length} openings
          </p>

          {filteredJobs.length === 0 ? (
            <EmptyState icon="🔍" title="No openings match your search" text="Try removing a filter or searching a different keyword.">
              <button type="button" className="btn btn-primary" onClick={() => setFilters(INITIAL_FILTERS)}>
                Clear filters
              </button>
            </EmptyState>
          ) : (
            <div className="job-grid">
              {filteredJobs.map((job) => (
                <JobCard key={job.id} job={job} applied={hasApplied(job.id)} onApply={setSelectedJob} />
              ))}
            </div>
          )}
        </>
      )}

      {selectedJob && (
        <ApplyModal
          job={selectedJob}
          user={user}
          onClose={() => setSelectedJob(null)}
          onSubmit={applyToJob}
        />
      )}
    </div>
  );
}

export default Jobs;
