import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { useApplications } from "../context/ApplicationsContext.jsx";
import StatusBadge from "../components/StatusBadge.jsx";
import CompanyLogo from "../components/CompanyLogo.jsx";
import EmptyState from "../components/EmptyState.jsx";
import { STATUSES, ACTIVE_STATUSES, STATUS_FLOW } from "../constants.js";
import { formatDate, formatDateTime } from "../utils/dates.js";

function Applications() {
  const { applications, updateStatus, withdrawApplication } = useApplications();
  const [statusFilter, setStatusFilter] = useState("All");
  const [openHistory, setOpenHistory] = useState(null);

  const sorted = useMemo(
    () => [...applications].sort((a, b) => new Date(b.appliedAt) - new Date(a.appliedAt)),
    [applications]
  );

  const visible = statusFilter === "All" ? sorted : sorted.filter((a) => a.status === statusFilter);

  const countFor = (status) =>
    status === "All" ? applications.length : applications.filter((a) => a.status === status).length;

  function handleWithdraw(application) {
    const confirmed = window.confirm(
      `Withdraw your application for ${application.title} at ${application.company}?`
    );
    if (confirmed) withdrawApplication(application.id);
  }

  return (
    <div>
      <div className="page-header">
        <h1>My applications</h1>
        <p className="muted">Track the progress of every position you applied for.</p>
      </div>

      <p className="banner">
        Demo note: there are no real employers behind this data, so use the "Update status (demo)" menu to simulate progress.
      </p>

      <div className="tabs" role="tablist" aria-label="Filter by status">
        {["All", ...STATUSES].map((status) => (
          <button
            key={status}
            type="button"
            role="tab"
            aria-selected={statusFilter === status}
            className={`tab ${statusFilter === status ? "active" : ""}`}
            onClick={() => setStatusFilter(status)}
          >
            {status} <span className="tab-count">{countFor(status)}</span>
          </button>
        ))}
      </div>

      {applications.length === 0 ? (
        <EmptyState icon="📄" title="No applications yet" text="Apply to an opening and it will show up here.">
          <Link to="/jobs" className="btn btn-primary">Browse opportunities</Link>
        </EmptyState>
      ) : visible.length === 0 ? (
        <EmptyState icon="🔍" title={`No applications with status "${statusFilter}"`} />
      ) : (
        <ul className="app-list">
          {visible.map((a) => {
            const nextOptions = STATUS_FLOW[a.status] || [];
            const canWithdraw = ACTIVE_STATUSES.includes(a.status);
            const historyOpen = openHistory === a.id;

            return (
              <li key={a.id} className="card app-card">
                <div className="app-main">
                  <CompanyLogo name={a.company} />
                  <div className="grow">
                    <h3>{a.title}</h3>
                    <p className="muted">{a.company} · {a.location} · {a.packageLabel}</p>
                    <p className="muted small">Applied on {formatDate(a.appliedAt)}</p>
                    {a.status === "Interview Scheduled" && a.interviewDate && (
                      <p className="interview-line">
                        🗓️ {a.interviewRound}: {formatDateTime(a.interviewDate)}
                      </p>
                    )}
                    {a.note && <p className="small">Your note: {a.note}</p>}
                  </div>
                  <StatusBadge status={a.status} />
                </div>

                <div className="app-actions">
                  <button
                    type="button"
                    className="link-btn"
                    onClick={() => setOpenHistory(historyOpen ? null : a.id)}
                    aria-expanded={historyOpen}
                  >
                    {historyOpen ? "Hide timeline" : "Show timeline"}
                  </button>

                  {nextOptions.length > 0 && (
                    <select
                      className="input input-sm"
                      aria-label={`Update status for ${a.title} at ${a.company} (demo)`}
                      value=""
                      onChange={(e) => e.target.value && updateStatus(a.id, e.target.value)}
                    >
                      <option value="">Update status (demo)</option>
                      {nextOptions.map((s) => <option key={s} value={s}>{s}</option>)}
                    </select>
                  )}

                  {canWithdraw && (
                    <button type="button" className="btn btn-danger btn-sm" onClick={() => handleWithdraw(a)}>
                      Withdraw
                    </button>
                  )}
                </div>

                {historyOpen && (
                  <ol className="timeline">
                    {a.history.map((step, index) => (
                      <li key={`${step.status}-${index}`}>
                        <span className="timeline-dot" aria-hidden="true"></span>
                        <strong>{step.status}</strong>
                        <span className="muted small"> · {formatDate(step.at)}</span>
                      </li>
                    ))}
                  </ol>
                )}
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

export default Applications;
