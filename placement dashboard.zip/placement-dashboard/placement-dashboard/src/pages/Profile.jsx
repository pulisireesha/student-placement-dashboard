import { useState } from "react";
import { useAuth } from "../context/AuthContext.jsx";
import FormField from "../components/FormField.jsx";
import { validateProfile } from "../utils/validators.js";
import { getProfileCompletion } from "../utils/profile.js";
import { DEPARTMENTS, YEARS, RESUME_STATUSES } from "../constants.js";
import { initials, colorFor } from "../utils/format.js";

const MAX_SKILLS = 15;

function Profile() {
  const { user, updateProfile } = useAuth();

  const [values, setValues] = useState({
    name: user.name,
    email: user.email,
    phone: user.phone,
    department: user.department,
    year: user.year,
    college: user.college,
    resumeStatus: user.resumeStatus,
    skills: user.skills || [],
  });
  const [skillInput, setSkillInput] = useState("");
  const [skillError, setSkillError] = useState("");
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState({ type: "", text: "" });

  // Completion is calculated from the values currently in the form
  const completion = getProfileCompletion(values);

  function handleChange(event) {
    const { name, value } = event.target;
    setValues((current) => ({ ...current, [name]: value }));
    if (errors[name]) setErrors((current) => ({ ...current, [name]: "" }));
    setMessage({ type: "", text: "" });
  }

  function addSkill() {
    const skill = skillInput.trim();
    if (!skill) {
      setSkillError("Type a skill first.");
      return;
    }
    if (skill.length > 30) {
      setSkillError("A skill can have at most 30 characters.");
      return;
    }
    if (values.skills.some((s) => s.toLowerCase() === skill.toLowerCase())) {
      setSkillError("You already added this skill.");
      return;
    }
    if (values.skills.length >= MAX_SKILLS) {
      setSkillError(`You can add up to ${MAX_SKILLS} skills.`);
      return;
    }
    setValues((current) => ({ ...current, skills: [...current.skills, skill] }));
    setSkillInput("");
    setSkillError("");
    setMessage({ type: "", text: "" });
  }

  function removeSkill(skill) {
    setValues((current) => ({ ...current, skills: current.skills.filter((s) => s !== skill) }));
    setMessage({ type: "", text: "" });
  }

  function handleSkillKey(event) {
    // Enter adds the skill instead of submitting the whole form
    if (event.key === "Enter") {
      event.preventDefault();
      addSkill();
    }
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setMessage({ type: "", text: "" });

    const validation = validateProfile(values);
    setErrors(validation);
    if (Object.keys(validation).length > 0) return;

    setSaving(true);
    try {
      await updateProfile(values);
      setMessage({ type: "success", text: "Profile saved." });
    } catch (err) {
      setMessage({ type: "error", text: err.message });
    } finally {
      setSaving(false);
    }
  }

  const inputProps = (name) => ({
    id: name,
    name,
    value: values[name],
    onChange: handleChange,
    className: `input ${errors[name] ? "invalid" : ""}`,
    "aria-invalid": errors[name] ? "true" : "false",
    "aria-describedby": errors[name] ? `${name}-error` : undefined,
  });

  return (
    <div>
      <div className="page-header">
        <h1>My profile</h1>
        <p className="muted">Keep your details up to date before you apply.</p>
      </div>

      <div className="profile-layout">
        <aside className="card profile-summary">
          <span className="avatar large" style={{ background: colorFor(values.name) }}>
            {initials(values.name)}
          </span>
          <h2>{values.name || "Your name"}</h2>
          <p className="muted">{values.department || "Department"} · {values.year || "Year"}</p>

          <p className="completion-label">
            Profile completion <strong>{completion.percent}%</strong>
          </p>
          <div
            className="progress"
            role="progressbar"
            aria-valuenow={completion.percent}
            aria-valuemin="0"
            aria-valuemax="100"
            aria-label="Profile completion"
          >
            <div className="progress-bar" style={{ width: `${completion.percent}%` }}></div>
          </div>

          {completion.missing.length > 0 ? (
            <>
              <p className="small muted">To reach 100%:</p>
              <ul className="missing-list">
                {completion.missing.map((item) => <li key={item}>{item}</li>)}
              </ul>
            </>
          ) : (
            <p className="small success-text">Your profile is complete.</p>
          )}
        </aside>

        <form className="card" onSubmit={handleSubmit} noValidate>
          {message.text && (
            <p className={message.type === "success" ? "form-success" : "form-error"} role="status">
              {message.text}
            </p>
          )}

          <div className="form-grid">
            <FormField id="name" label="Full name" error={errors.name}>
              <input type="text" autoComplete="name" {...inputProps("name")} />
            </FormField>
            <FormField id="email" label="Email" error={errors.email}>
              <input type="email" autoComplete="email" {...inputProps("email")} />
            </FormField>
            <FormField id="phone" label="Phone" error={errors.phone}>
              <input type="tel" autoComplete="tel" {...inputProps("phone")} />
            </FormField>
            <FormField id="college" label="College / university" error={errors.college}>
              <input type="text" {...inputProps("college")} />
            </FormField>
            <FormField id="department" label="Department" error={errors.department}>
              <select {...inputProps("department")}>
                <option value="">Select department</option>
                {DEPARTMENTS.map((d) => <option key={d} value={d}>{d}</option>)}
              </select>
            </FormField>
            <FormField id="year" label="Year of study" error={errors.year}>
              <select {...inputProps("year")}>
                <option value="">Select year</option>
                {YEARS.map((y) => <option key={y} value={y}>{y}</option>)}
              </select>
            </FormField>
            <FormField id="resumeStatus" label="Resume status" hint="This demo does not upload files; it only tracks the status.">
              <select id="resumeStatus" name="resumeStatus" className="input" value={values.resumeStatus} onChange={handleChange}>
                {RESUME_STATUSES.map((r) => <option key={r} value={r}>{r}</option>)}
              </select>
            </FormField>
          </div>

          <div className="field">
            <label htmlFor="skill-input">Skills</label>
            <div className="skill-row">
              <input
                id="skill-input"
                type="text"
                className="input"
                value={skillInput}
                onChange={(e) => { setSkillInput(e.target.value); setSkillError(""); }}
                onKeyDown={handleSkillKey}
                placeholder="e.g. Python"
              />
              <button type="button" className="btn btn-outline" onClick={addSkill}>Add</button>
            </div>
            {skillError && <p className="field-error" role="alert">{skillError}</p>}

            {values.skills.length > 0 && (
              <ul className="chips editable">
                {values.skills.map((skill) => (
                  <li key={skill} className="chip">
                    {skill}
                    <button type="button" onClick={() => removeSkill(skill)} aria-label={`Remove ${skill}`}>×</button>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <button type="submit" className="btn btn-primary" disabled={saving}>
            {saving ? "Saving..." : "Save profile"}
          </button>
        </form>
      </div>
    </div>
  );
}

export default Profile;
