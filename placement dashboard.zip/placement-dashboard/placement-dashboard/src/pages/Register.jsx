import { useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import FormField from "../components/FormField.jsx";
import PasswordInput from "../components/PasswordInput.jsx";
import { validateRegister } from "../utils/validators.js";
import { DEPARTMENTS, YEARS } from "../constants.js";

const EMPTY = {
  name: "", email: "", password: "", confirmPassword: "",
  phone: "", department: "", year: "", college: "",
};

function Register() {
  const { register } = useAuth();
  const [values, setValues] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState("");
  const [loading, setLoading] = useState(false);

  function handleChange(event) {
    const { name, value } = event.target;
    setValues((current) => ({ ...current, [name]: value }));
    if (errors[name]) setErrors((current) => ({ ...current, [name]: "" }));
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setFormError("");

    const validation = validateRegister(values);
    setErrors(validation);
    if (Object.keys(validation).length > 0) return;

    setLoading(true);
    try {
      await register(values); // the router redirects to the dashboard on success
    } catch (err) {
      setFormError(err.message);
      setLoading(false);
    }
  }

  const inputProps = (name) => ({
    id: name,
    name,
    value: values[name],
    onChange: handleChange,
    className: `input ${errors[name] ? "invalid" : ""}`,
    "aria-invalid": errors[name] ? "true" : "false",
    "aria-describedby": errors[name] ? `${name}-error` : undefined,
  });

  return (
    <div className="auth-page">
      <div className="auth-side">
        <h1>Create your student account</h1>
        <p>Build your profile, apply to opportunities and follow every application.</p>
      </div>

      <div className="auth-form-wrap">
        <form className="auth-card wide" onSubmit={handleSubmit} noValidate>
          <h2>Register</h2>
          <p className="muted">Demo registration: your data stays in this browser only.</p>

          {formError && <p className="form-error" role="alert">{formError}</p>}

          <div className="form-grid">
            <FormField id="name" label="Full name" error={errors.name}>
              <input type="text" placeholder="Your full name" autoComplete="name" {...inputProps("name")} />
            </FormField>

            <FormField id="email" label="Email" error={errors.email}>
              <input type="email" placeholder="you@college.edu" autoComplete="email" {...inputProps("email")} />
            </FormField>

            <FormField id="password" label="Password" error={errors.password} hint="At least 8 characters with a letter and a number.">
              <PasswordInput
                id="password" name="password" value={values.password} onChange={handleChange}
                placeholder="Create a password" hasError={Boolean(errors.password)} autoComplete="new-password"
              />
            </FormField>

            <FormField id="confirmPassword" label="Confirm password" error={errors.confirmPassword}>
              <PasswordInput
                id="confirmPassword" name="confirmPassword" value={values.confirmPassword} onChange={handleChange}
                placeholder="Repeat the password" hasError={Boolean(errors.confirmPassword)} autoComplete="new-password"
              />
            </FormField>

            <FormField id="phone" label="Phone number" error={errors.phone} hint="10-digit mobile number">
              <input type="tel" placeholder="9876543210" autoComplete="tel" {...inputProps("phone")} />
            </FormField>

            <FormField id="college" label="College / university" error={errors.college}>
              <input type="text" placeholder="Your college name" {...inputProps("college")} />
            </FormField>

            <FormField id="department" label="Department" error={errors.department}>
              <select {...inputProps("department")}>
                <option value="">Select department</option>
                {DEPARTMENTS.map((d) => <option key={d} value={d}>{d}</option>)}
              </select>
            </FormField>

            <FormField id="year" label="Year of study" error={errors.year}>
              <select {...inputProps("year")}>
                <option value="">Select year</option>
                {YEARS.map((y) => <option key={y} value={y}>{y}</option>)}
              </select>
            </FormField>
          </div>

          <button type="submit" className="btn btn-primary btn-block" disabled={loading}>
            {loading ? "Creating account..." : "Create account"}
          </button>

          <p className="auth-switch">
            Already registered? <Link to="/login">Log in</Link>
          </p>
        </form>
      </div>
    </div>
  );
}

export default Register;
