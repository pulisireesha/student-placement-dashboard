import { useApplications } from "../context/ApplicationsContext.jsx";
import EmptyState from "../components/EmptyState.jsx";
import { timeAgo } from "../utils/dates.js";

const ICONS = { info: "ℹ️", success: "🎉", warning: "⚠️", interview: "🗓️" };

function Notifications() {
  const { notifications, unreadCount, markNotificationRead, markAllRead, clearNotifications } = useApplications();

  function handleClear() {
    if (window.confirm("Delete all notifications?")) clearNotifications();
  }

  return (
    <div>
      <div className="page-header row-between">
        <div>
          <h1>Notifications</h1>
          <p className="muted">{unreadCount} unread</p>
        </div>
        {notifications.length > 0 && (
          <div className="button-row">
            <button type="button" className="btn btn-outline btn-sm" onClick={markAllRead} disabled={unreadCount === 0}>
              Mark all as read
            </button>
            <button type="button" className="btn btn-danger btn-sm" onClick={handleClear}>
              Clear all
            </button>
          </div>
        )}
      </div>

      {notifications.length === 0 ? (
        <EmptyState icon="🔔" title="You are all caught up" text="Updates about your applications will appear here." />
      ) : (
        <ul className="notification-list">
          {notifications.map((n) => (
            <li key={n.id}>
              <button
                type="button"
                className={`notification ${n.read ? "read" : "unread"}`}
                onClick={() => markNotificationRead(n.id)}
              >
                <span className="notification-icon" aria-hidden="true">{ICONS[n.type] || ICONS.info}</span>
                <span className="grow">
                  <strong>{n.title}</strong>
                  <span className="notification-message">{n.message}</span>
                  <span className="muted small">{timeAgo(n.createdAt)}</span>
                </span>
                {!n.read && <span className="unread-dot" aria-label="Unread"></span>}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default Notifications;
