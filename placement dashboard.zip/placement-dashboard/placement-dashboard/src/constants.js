export const DEMO_USER_ID = "demo-user";
export const DEMO_EMAIL = "demo@student.com";
export const DEMO_PASSWORD = "Demo@1234";

export const STATUSES = [
  "Applied",
  "Under Review",
  "Shortlisted",
  "Interview Scheduled",
  "Selected",
  "Rejected",
  "Withdrawn",
];

// Statuses counted as "in progress" on the dashboard
export const IN_PROGRESS_STATUSES = ["Applied", "Under Review", "Shortlisted"];

// Applications that can still be withdrawn
export const ACTIVE_STATUSES = [...IN_PROGRESS_STATUSES, "Interview Scheduled"];

// Demo only: which statuses an application can move to next
export const STATUS_FLOW = {
  Applied: ["Under Review"],
  "Under Review": ["Shortlisted", "Rejected"],
  Shortlisted: ["Interview Scheduled", "Rejected"],
  "Interview Scheduled": ["Selected", "Rejected"],
};

export const STATUS_CLASS = {
  Applied: "blue",
  "Under Review": "amber",
  Shortlisted: "purple",
  "Interview Scheduled": "indigo",
  Selected: "green",
  Rejected: "red",
  Withdrawn: "gray",
};

export const DEPARTMENTS = [
  "Computer Science (CSE)",
  "Information Technology (IT)",
  "Electronics & Communication (ECE)",
  "Electrical & Electronics (EEE)",
  "Mechanical",
  "Civil",
  "Other",
];

export const YEARS = ["1st Year", "2nd Year", "3rd Year", "4th Year"];
export const RESUME_STATUSES = ["Not uploaded", "Uploaded", "Needs update"];
