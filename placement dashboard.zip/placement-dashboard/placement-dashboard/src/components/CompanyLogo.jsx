import { colorFor } from "../utils/format.js";

// Coloured square with the company's first letter (used instead of real logos)
function CompanyLogo({ name, size = 44 }) {
  return (
    <span
      className="company-logo"
      style={{ background: colorFor(name), width: size, height: size, fontSize: size * 0.45 }}
      aria-hidden="true"
    >
      {name.charAt(0).toUpperCase()}
    </span>
  );
}

export default CompanyLogo;
