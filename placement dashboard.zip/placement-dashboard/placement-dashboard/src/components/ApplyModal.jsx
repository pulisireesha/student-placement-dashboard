import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import CompanyLogo from "./CompanyLogo.jsx";
import { getProfileCompletion } from "../utils/profile.js";
import { formatDate } from "../utils/dates.js";

const NOTE_LIMIT = 300;

// Confirmation dialog shown when the student clicks Apply
function ApplyModal({ job, user, onClose, onSubmit }) {
  const [note, setNote] = useState("");
  const [error, setError] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const { percent } = getProfileCompletion(user);
  const noResume = user.resumeStatus === "Not uploaded";
  const outdatedResume = user.resumeStatus === "Needs update";

  // Close with the Escape key
  useEffect(() => {
    function handleKey(event) {
      if (event.key === "Escape") onClose();
    }
    document.addEventListener("keydown", handleKey);
    return () => document.removeEventListener("keydown", handleKey);
  }, [onClose]);

  function handleSubmit(event) {
    event.preventDefault();
    if (noResume) return;
    if (note.length > NOTE_LIMIT) {
      setError(`Note must be ${NOTE_LIMIT} characters or fewer.`);
      return;
    }
    const result = onSubmit(job, note);
    if (result.ok) setSubmitted(true);
    else setError(result.error);
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div
        className="modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="apply-title"
        onClick={(e) => e.stopPropagation()}
      >
        {submitted ? (
          <div className="modal-success">
            <span className="empty-icon" aria-hidden="true">✅</span>
            <h2 id="apply-title">Application submitted</h2>
            <p>
              Your application for <strong>{job.title}</strong> at <strong>{job.company}</strong> has been
              recorded. You can follow its progress on the Applications page.
            </p>
            <div className="modal-actions">
              <Link to="/applications" className="btn btn-primary" onClick={onClose}>View applications</Link>
              <button type="button" className="btn btn-outline" onClick={onClose}>Keep browsing</button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} noValidate>
            <h2 id="apply-title">Apply for this position</h2>

            <div className="modal-job">
              <CompanyLogo name={job.company} />
              <div>
                <p><strong>{job.title}</strong></p>
                <p className="muted small">
                  {job.company} · {job.location} · {job.packageLabel}
                </p>
                <p className="muted small">Deadline: {formatDate(job.deadline)}</p>
              </div>
            </div>

            <div className="summary-box">
              <p><strong>Applying as:</strong> {user.name}</p>
              <p><strong>Resume:</strong> {user.resumeStatus} · <strong>Profile:</strong> {percent}% complete</p>
            </div>

            {noResume && (
              <p className="form-error" role="alert">
                Your resume status is "Not uploaded". Update it in your <Link to="/profile" onClick={onClose}>profile</Link> before applying.
              </p>
            )}
            {outdatedResume && (
              <p className="form-warning">
                Your resume is marked "Needs update". You can still apply, but updating it first is recommended.
              </p>
            )}

            <label htmlFor="apply-note">Note to recruiter (optional)</label>
            <textarea
              id="apply-note"
              className="input textarea"
              rows="4"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Briefly say why you are a good fit."
            />
            <p className="hint">{note.length} / {NOTE_LIMIT}</p>

            {error && <p className="form-error" role="alert">{error}</p>}

            <div className="modal-actions">
              <button type="submit" className="btn btn-primary" disabled={noResume}>
                Submit application
              </button>
              <button type="button" className="btn btn-outline" onClick={onClose}>Cancel</button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

export default ApplyModal;
