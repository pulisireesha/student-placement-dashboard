import { useState } from "react";
import CompanyLogo from "./CompanyLogo.jsx";
import { formatDate, deadlineLabel, daysUntil } from "../utils/dates.js";

// One job opening. The Apply button calls onApply(job).
function JobCard({ job, applied, onApply }) {
  const [expanded, setExpanded] = useState(false);
  const closed = new Date(job.deadline).getTime() < Date.now();
  const urgent = !closed && daysUntil(job.deadline) <= 7;

  return (
    <article className="job-card">
      <header className="job-head">
        <CompanyLogo name={job.company} />
        <div>
          <h3>{job.title}</h3>
          <p className="muted">{job.company}</p>
        </div>
        <span className="job-type">{job.type}</span>
      </header>

      <dl className="job-meta">
        <div><dt>Location</dt><dd>{job.location}</dd></div>
        <div><dt>Package</dt><dd>{job.packageLabel}</dd></div>
        <div><dt>Eligibility</dt><dd>{job.eligibility} · CGPA {job.minCgpa}+</dd></div>
        <div><dt>Posted</dt><dd>{formatDate(job.postedDate)}</dd></div>
      </dl>

      <ul className="chips" aria-label="Required skills">
        {job.skills.map((skill) => (
          <li key={skill} className="chip">{skill}</li>
        ))}
      </ul>

      <p className={`job-description ${expanded ? "expanded" : ""}`}>{job.description}</p>
      <button type="button" className="link-btn" onClick={() => setExpanded((e) => !e)}>
        {expanded ? "Show less" : "Show more"}
      </button>

      <footer className="job-foot">
        <p className={`deadline ${urgent ? "urgent" : ""} ${closed ? "closed" : ""}`}>
          Apply by {formatDate(job.deadline)}
          <small> · {deadlineLabel(job.deadline)}</small>
        </p>
        <button
          type="button"
          className="btn btn-primary btn-sm"
          disabled={applied || closed}
          onClick={() => onApply(job)}
        >
          {applied ? "Applied ✓" : closed ? "Closed" : "Apply"}
        </button>
      </footer>
    </article>
  );
}

export default JobCard;
