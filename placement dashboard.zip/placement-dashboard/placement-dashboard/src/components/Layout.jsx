import { useState } from "react";
import { NavLink, Outlet, Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import { useApplications } from "../context/ApplicationsContext.jsx";
import { initials, colorFor } from "../utils/format.js";

const NAV_ITEMS = [
  { to: "/dashboard", label: "Dashboard", icon: "🏠" },
  { to: "/jobs", label: "Opportunities", icon: "💼" },
  { to: "/applications", label: "Applications", icon: "📄" },
  { to: "/analytics", label: "Analytics", icon: "📊" },
  { to: "/notifications", label: "Notifications", icon: "🔔" },
  { to: "/profile", label: "Profile", icon: "👤" },
];

// App shell: sidebar + top bar + the current page
function Layout() {
  const { user, logout } = useAuth();
  const { unreadCount } = useApplications();
  const [menuOpen, setMenuOpen] = useState(false);

  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="app-shell">
      <aside className={`sidebar ${menuOpen ? "open" : ""}`} aria-label="Main navigation">
        <div className="sidebar-brand">
          <span aria-hidden="true">🎓</span> Placement Hub
        </div>
        <nav>
          {NAV_ITEMS.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              onClick={closeMenu}
              className={({ isActive }) => `nav-link ${isActive ? "active" : ""}`}
            >
              <span aria-hidden="true">{item.icon}</span>
              {item.label}
              {item.to === "/notifications" && unreadCount > 0 && (
                <span className="nav-count">{unreadCount}</span>
              )}
            </NavLink>
          ))}
        </nav>
        <p className="sidebar-note">Demo project with sample data</p>
      </aside>

      {menuOpen && <div className="overlay" onClick={closeMenu} aria-hidden="true"></div>}

      <div className="main-area">
        <header className="topbar">
          <button
            type="button"
            className="menu-btn"
            onClick={() => setMenuOpen((open) => !open)}
            aria-label="Toggle navigation menu"
            aria-expanded={menuOpen}
          >
            ☰
          </button>
          <p className="topbar-title">Student Placement Dashboard</p>

          <div className="topbar-right">
            <Link to="/notifications" className="bell" aria-label={`Notifications, ${unreadCount} unread`}>
              🔔
              {unreadCount > 0 && <span className="badge-dot">{unreadCount}</span>}
            </Link>
            <Link to="/profile" className="user-chip">
              <span className="avatar" style={{ background: colorFor(user.name) }}>
                {initials(user.name)}
              </span>
              <span className="user-name">{user.name}</span>
            </Link>
            <button type="button" className="btn btn-outline btn-sm" onClick={logout}>
              Log out
            </button>
          </div>
        </header>

        <main className="page">
          <Outlet />
        </main>
      </div>
    </div>
  );
}

export default Layout;
