import { Navigate, Outlet, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";

// Login and register pages: signed-in students are sent to the dashboard
function PublicOnlyRoute() {
  const { user } = useAuth();
  const location = useLocation();

  if (user) {
    const destination = location.state?.from?.pathname || "/dashboard";
    return <Navigate to={destination} replace />;
  }
  return <Outlet />;
}

export default PublicOnlyRoute;
