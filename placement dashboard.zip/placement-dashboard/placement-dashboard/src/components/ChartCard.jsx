// Card wrapper with a title for each chart
function ChartCard({ title, subtitle, children }) {
  return (
    <section className="card chart-card">
      <h2 className="card-title">{title}</h2>
      {subtitle && <p className="muted small">{subtitle}</p>}
      <div className="chart-box">{children}</div>
    </section>
  );
}

export default ChartCard;
