import { STATUS_CLASS } from "../constants.js";

function StatusBadge({ status }) {
  return <span className={`status-badge ${STATUS_CLASS[status] || "gray"}`}>{status}</span>;
}

export default StatusBadge;
