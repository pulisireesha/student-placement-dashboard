function StatCard({ icon, label, value, tone = "blue" }) {
  return (
    <article className="stat-card">
      <span className={`stat-icon ${tone}`} aria-hidden="true">
        {icon}
      </span>
      <div>
        <p className="stat-value">{value}</p>
        <p className="stat-label">{label}</p>
      </div>
    </article>
  );
}

export default StatCard;
