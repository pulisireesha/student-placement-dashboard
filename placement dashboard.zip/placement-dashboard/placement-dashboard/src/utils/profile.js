// Each item is worth the same share of the profile completion percentage
export function getProfileCompletion(user) {
  const checks = [
    { label: "Full name", done: Boolean(user.name?.trim()) },
    { label: "Email", done: Boolean(user.email?.trim()) },
    { label: "Phone number", done: Boolean(user.phone?.trim()) },
    { label: "Department", done: Boolean(user.department) },
    { label: "Year of study", done: Boolean(user.year) },
    { label: "College / university", done: Boolean(user.college?.trim()) },
    { label: "At least 3 skills", done: (user.skills || []).length >= 3 },
    { label: "Resume uploaded", done: user.resumeStatus === "Uploaded" },
  ];
  const doneCount = checks.filter((c) => c.done).length;
  return {
    percent: Math.round((doneCount / checks.length) * 100),
    missing: checks.filter((c) => !c.done).map((c) => c.label),
  };
}
