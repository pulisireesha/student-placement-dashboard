const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export const isValidEmail = (email) => EMAIL_PATTERN.test(email.trim());

// Accepts a 10-digit Indian mobile number (optionally with +91 or spaces)
export function normalizePhone(phone) {
  let digits = phone.replace(/\D/g, "");
  if (digits.length === 12 && digits.startsWith("91")) digits = digits.slice(2);
  return digits;
}
export const isValidPhone = (phone) => /^[6-9]\d{9}$/.test(normalizePhone(phone));

function validatePassword(password) {
  if (!password) return "Password is required.";
  if (password.length < 8) return "Password must be at least 8 characters.";
  if (!/[A-Za-z]/.test(password) || !/\d/.test(password)) {
    return "Password must contain at least one letter and one number.";
  }
  return "";
}

export function validateLogin({ email, password }) {
  const errors = {};
  if (!email.trim()) errors.email = "Email is required.";
  else if (!isValidEmail(email)) errors.email = "Enter a valid email address.";
  if (!password) errors.password = "Password is required.";
  else if (password.length < 8) errors.password = "Password must be at least 8 characters.";
  return errors;
}

export function validateRegister(values) {
  const errors = {};
  if (!values.name.trim()) errors.name = "Full name is required.";
  else if (values.name.trim().length < 3) errors.name = "Name must be at least 3 characters.";

  if (!values.email.trim()) errors.email = "Email is required.";
  else if (!isValidEmail(values.email)) errors.email = "Enter a valid email address.";

  const passwordError = validatePassword(values.password);
  if (passwordError) errors.password = passwordError;

  if (!values.confirmPassword) errors.confirmPassword = "Please confirm your password.";
  else if (values.confirmPassword !== values.password) errors.confirmPassword = "Passwords do not match.";

  if (!values.phone.trim()) errors.phone = "Phone number is required.";
  else if (!isValidPhone(values.phone)) errors.phone = "Enter a valid 10-digit mobile number.";

  if (!values.department) errors.department = "Select your department.";
  if (!values.year) errors.year = "Select your year of study.";
  if (!values.college.trim()) errors.college = "College / university is required.";
  return errors;
}

export function validateProfile(values) {
  const errors = {};
  if (!values.name.trim()) errors.name = "Name is required.";
  else if (values.name.trim().length < 3) errors.name = "Name must be at least 3 characters.";
  if (!values.email.trim()) errors.email = "Email is required.";
  else if (!isValidEmail(values.email)) errors.email = "Enter a valid email address.";
  if (!values.phone.trim()) errors.phone = "Phone number is required.";
  else if (!isValidPhone(values.phone)) errors.phone = "Enter a valid 10-digit mobile number.";
  if (!values.department) errors.department = "Select your department.";
  if (!values.year) errors.year = "Select your year of study.";
  if (!values.college.trim()) errors.college = "College / university is required.";
  return errors;
}
