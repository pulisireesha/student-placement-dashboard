// Returns an ISO date string `days` from now. Optionally sets a clock time.
export function addDays(days, hour = null, minute = 0) {
  const date = new Date();
  date.setDate(date.getDate() + days);
  if (hour !== null) date.setHours(hour, minute, 0, 0);
  return date.toISOString();
}

export function formatDate(iso) {
  if (!iso) return "N/A";
  return new Date(iso).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
}

export function formatDateTime(iso) {
  if (!iso) return "N/A";
  return new Date(iso).toLocaleString("en-GB", {
    day: "numeric", month: "short", year: "numeric", hour: "numeric", minute: "2-digit",
  });
}

// Whole days from now until the date (negative if the date has passed)
export function daysUntil(iso) {
  return Math.ceil((new Date(iso).getTime() - Date.now()) / 86400000);
}

export function deadlineLabel(iso) {
  const days = daysUntil(iso);
  if (new Date(iso).getTime() < Date.now()) return "Closed";
  if (days <= 1) return "Closes today";
  return `${days} days left`;
}

export function timeAgo(iso) {
  const minutes = Math.floor((Date.now() - new Date(iso).getTime()) / 60000);
  if (minutes < 1) return "Just now";
  if (minutes < 60) return `${minutes} min ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} hr ago`;
  const days = Math.floor(hours / 24);
  return days === 1 ? "Yesterday" : `${days} days ago`;
}
