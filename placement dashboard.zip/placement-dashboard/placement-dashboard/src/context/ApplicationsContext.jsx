import { createContext, useContext, useMemo, useCallback } from "react";
import useLocalStorage from "../hooks/useLocalStorage.js";
import { DEMO_USER_ID, IN_PROGRESS_STATUSES } from "../constants.js";
import { addDays } from "../utils/dates.js";
import { uid } from "../utils/format.js";

// Holds the signed-in student's applications and notifications.
// Data is saved per student in localStorage.
const ApplicationsContext = createContext(null);

// ----- Sample data for the demo account -----
function buildHistory(path, appliedDaysAgo) {
  const step = Math.max(1, Math.floor(appliedDaysAgo / path.length));
  return path.map((status, index) => ({
    status,
    at: addDays(-Math.max(0, appliedDaysAgo - index * step)),
  }));
}

function seedApplication(job, path, appliedDaysAgo, interviewInDays = null) {
  return {
    id: `app_${uid()}`,
    jobId: job.id,
    company: job.company,
    title: job.title,
    location: job.location,
    packageLabel: job.packageLabel,
    jobType: job.type,
    appliedAt: addDays(-appliedDaysAgo),
    status: path[path.length - 1],
    interviewDate: interviewInDays !== null ? addDays(interviewInDays, 10) : null,
    interviewRound: interviewInDays !== null ? "Technical Interview" : null,
    note: "",
    history: buildHistory(path, appliedDaysAgo),
  };
}

function createDemoApplications() {
  return [
    seedApplication({ id: "job-1", company: "TechNova Solutions", title: "Software Engineer Trainee", location: "Bengaluru", packageLabel: "6.5 LPA", type: "Full-time" },
      ["Applied", "Under Review", "Shortlisted", "Interview Scheduled"], 8, 3),
    seedApplication({ id: "job-2", company: "Infosys", title: "Systems Engineer", location: "Pune", packageLabel: "4.0 LPA", type: "Full-time" },
      ["Applied", "Under Review"], 5),
    seedApplication({ id: "job-3", company: "TCS", title: "Assistant System Engineer", location: "Chennai", packageLabel: "3.6 LPA", type: "Full-time" },
      ["Applied"], 1),
    seedApplication({ id: "job-5", company: "Accenture", title: "Associate Software Engineer", location: "Bengaluru", packageLabel: "4.6 LPA", type: "Full-time" },
      ["Applied", "Under Review", "Shortlisted", "Interview Scheduled", "Selected"], 20),
    seedApplication({ id: "job-4", company: "Wipro", title: "Project Engineer", location: "Hyderabad", packageLabel: "3.5 LPA", type: "Full-time" },
      ["Applied", "Under Review", "Rejected"], 14),
    seedApplication({ id: "job-7", company: "Zoho", title: "Member Technical Staff", location: "Chennai", packageLabel: "8.0 LPA", type: "Full-time" },
      ["Applied", "Under Review", "Shortlisted"], 6),
  ];
}

function createDemoNotifications() {
  return [
    { id: `n_${uid()}a`, title: "Interview scheduled", message: "Your technical interview with TechNova Solutions is scheduled. Check the Applications page for the date.", type: "interview", createdAt: addDays(-1), read: false },
    { id: `n_${uid()}b`, title: "Congratulations!", message: "You were selected for Associate Software Engineer at Accenture.", type: "success", createdAt: addDays(-3), read: false },
    { id: `n_${uid()}c`, title: "Complete your profile", message: "Add more skills to improve your profile completion.", type: "info", createdAt: addDays(-5), read: true },
  ];
}

export function ApplicationsProvider({ userId, children }) {
  const isDemo = userId === DEMO_USER_ID;
  const [applications, setApplications] = useLocalStorage(
    `spd_applications_${userId}`,
    () => (isDemo ? createDemoApplications() : [])
  );
  const [notifications, setNotifications] = useLocalStorage(
    `spd_notifications_${userId}`,
    () => (isDemo ? createDemoNotifications() : [])
  );

  const addNotification = useCallback(
    (title, message, type = "info") => {
      setNotifications((current) => [
        { id: `n_${uid()}`, title, message, type, createdAt: new Date().toISOString(), read: false },
        ...current,
      ]);
    },
    [setNotifications]
  );

  // A job counts as applied unless the student withdrew
  const hasApplied = useCallback(
    (jobId) => applications.some((a) => a.jobId === jobId && a.status !== "Withdrawn"),
    [applications]
  );

  const applyToJob = useCallback(
    (job, note = "") => {
      if (hasApplied(job.id)) {
        return { ok: false, error: "You have already applied for this position." };
      }
      const now = new Date().toISOString();
      const application = {
        id: `app_${uid()}`,
        jobId: job.id,
        company: job.company,
        title: job.title,
        location: job.location,
        packageLabel: job.packageLabel,
        jobType: job.type,
        appliedAt: now,
        status: "Applied",
        interviewDate: null,
        interviewRound: null,
        note: note.trim(),
        history: [{ status: "Applied", at: now }],
      };
      setApplications((current) => [application, ...current]);
      addNotification("Application submitted", `Your application for ${job.title} at ${job.company} was submitted.`, "info");
      return { ok: true };
    },
    [hasApplied, setApplications, addNotification]
  );

  // Demo only: there is no real employer, so the student moves an application along manually
  const updateStatus = useCallback(
    (applicationId, status) => {
      const target = applications.find((a) => a.id === applicationId);
      if (!target) return;

      const now = new Date().toISOString();
      setApplications((current) =>
        current.map((a) =>
          a.id !== applicationId
            ? a
            : {
                ...a,
                status,
                interviewDate: status === "Interview Scheduled" ? addDays(3, 10) : a.interviewDate,
                interviewRound: status === "Interview Scheduled" ? "Technical Interview" : a.interviewRound,
                history: [...a.history, { status, at: now }],
              }
        )
      );

      const type = status === "Selected" ? "success" : status === "Rejected" ? "warning" : status === "Interview Scheduled" ? "interview" : "info";
      addNotification(
        `Status updated: ${target.company}`,
        `Your application for ${target.title} is now "${status}".`,
        type
      );
    },
    [applications, setApplications, addNotification]
  );

  const withdrawApplication = useCallback(
    (applicationId) => {
      const target = applications.find((a) => a.id === applicationId);
      if (!target) return;
      const now = new Date().toISOString();
      setApplications((current) =>
        current.map((a) =>
          a.id !== applicationId
            ? a
            : { ...a, status: "Withdrawn", interviewDate: null, history: [...a.history, { status: "Withdrawn", at: now }] }
        )
      );
      addNotification("Application withdrawn", `You withdrew your application for ${target.title} at ${target.company}.`, "info");
    },
    [applications, setApplications, addNotification]
  );

  const markNotificationRead = useCallback(
    (id) => setNotifications((current) => current.map((n) => (n.id === id ? { ...n, read: true } : n))),
    [setNotifications]
  );
  const markAllRead = useCallback(
    () => setNotifications((current) => current.map((n) => ({ ...n, read: true }))),
    [setNotifications]
  );
  const clearNotifications = useCallback(() => setNotifications([]), [setNotifications]);

  const counts = useMemo(() => {
    const counted = applications.filter((a) => a.status !== "Withdrawn");
    return {
      total: counted.length,
      inProgress: counted.filter((a) => IN_PROGRESS_STATUSES.includes(a.status)).length,
      interviews: counted.filter((a) => a.status === "Interview Scheduled").length,
      selected: counted.filter((a) => a.status === "Selected").length,
      rejected: counted.filter((a) => a.status === "Rejected").length,
    };
  }, [applications]);

  const unreadCount = notifications.filter((n) => !n.read).length;

  const value = useMemo(
    () => ({
      applications, notifications, counts, unreadCount,
      hasApplied, applyToJob, updateStatus, withdrawApplication,
      markNotificationRead, markAllRead, clearNotifications,
    }),
    [applications, notifications, counts, unreadCount, hasApplied, applyToJob, updateStatus,
     withdrawApplication, markNotificationRead, markAllRead, clearNotifications]
  );

  return <ApplicationsContext.Provider value={value}>{children}</ApplicationsContext.Provider>;
}

export function useApplications() {
  const context = useContext(ApplicationsContext);
  if (!context) throw new Error("useApplications must be used inside ApplicationsProvider");
  return context;
}
