import { createContext, useContext, useEffect, useMemo, useState, useCallback } from "react";
import { fetchJobs, fetchAnnouncements, fetchPlacementStats } from "../services/api.js";
import { addDays } from "../utils/dates.js";

// Loads the sample jobs, announcements and placement statistics with fetch()
const DataContext = createContext(null);

export function DataProvider({ children }) {
  const [jobs, setJobs] = useState([]);
  const [announcements, setAnnouncements] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      setLoading(true);
      setError("");
      try {
        const [jobData, announcementData, statsData] = await Promise.all([
          fetchJobs(),
          fetchAnnouncements(),
          fetchPlacementStats(),
        ]);
        if (cancelled) return;

        // The sample data stores dates as "days from today" so deadlines always look current
        setJobs(
          jobData.map((job) => ({
            ...job,
            postedDate: addDays(-job.postedDaysAgo),
            deadline: addDays(job.deadlineInDays, 23, 59),
          }))
        );
        setAnnouncements(
          announcementData.map((item) => ({ ...item, date: addDays(-item.daysAgo) }))
        );
        setStats(statsData);
      } catch (err) {
        if (!cancelled) setError("Could not load placement data. Please check that the app is running and try again.");
        console.error(err);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, [attempt]);

  const retry = useCallback(() => setAttempt((n) => n + 1), []);

  const value = useMemo(
    () => ({ jobs, announcements, stats, loading, error, retry }),
    [jobs, announcements, stats, loading, error, retry]
  );

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
}

export function useData() {
  const context = useContext(DataContext);
  if (!context) throw new Error("useData must be used inside DataProvider");
  return context;
}
