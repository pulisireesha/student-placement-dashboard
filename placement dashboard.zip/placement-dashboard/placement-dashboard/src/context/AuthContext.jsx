import { createContext, useContext, useMemo, useCallback } from "react";
import useLocalStorage from "../hooks/useLocalStorage.js";
import { DEMO_USER_ID, DEMO_EMAIL, DEMO_PASSWORD } from "../constants.js";
import { uid } from "../utils/format.js";

/*
  FRONTEND DEMO AUTHENTICATION ONLY.
  Users and passwords are stored in the browser's localStorage in plain text.
  This is NOT secure and must never be used in a real application.
*/

const AuthContext = createContext(null);

const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function createDemoUsers() {
  return [
    {
      id: DEMO_USER_ID,
      name: "Aarav Sharma",
      email: DEMO_EMAIL,
      password: DEMO_PASSWORD,
      phone: "9876543210",
      department: "Computer Science (CSE)",
      year: "4th Year",
      college: "Demo Institute of Technology",
      skills: ["JavaScript", "React", "Java", "SQL"],
      resumeStatus: "Uploaded",
    },
  ];
}

export function AuthProvider({ children }) {
  const [users, setUsers] = useLocalStorage("spd_users", createDemoUsers);
  const [sessionId, setSessionId] = useLocalStorage("spd_session", null);

  const user = users.find((u) => u.id === sessionId) || null;

  const login = useCallback(
    async (email, password) => {
      await wait(700); // simulate a network request
      const found = users.find((u) => u.email.toLowerCase() === email.trim().toLowerCase());
      if (!found || found.password !== password) {
        throw new Error("Invalid email or password.");
      }
      setSessionId(found.id);
    },
    [users, setSessionId]
  );

  const register = useCallback(
    async (values) => {
      await wait(900);
      const email = values.email.trim().toLowerCase();
      if (users.some((u) => u.email.toLowerCase() === email)) {
        throw new Error("An account with this email already exists.");
      }
      const newUser = {
        id: `u_${uid()}`,
        name: values.name.trim(),
        email,
        password: values.password,
        phone: values.phone.trim(),
        department: values.department,
        year: values.year,
        college: values.college.trim(),
        skills: [],
        resumeStatus: "Not uploaded",
      };
      setUsers((current) => [...current, newUser]);
      setSessionId(newUser.id);
    },
    [users, setUsers, setSessionId]
  );

  const logout = useCallback(() => setSessionId(null), [setSessionId]);

  const updateProfile = useCallback(
    async (updates) => {
      await wait(400);
      const email = updates.email.trim().toLowerCase();
      if (users.some((u) => u.id !== sessionId && u.email.toLowerCase() === email)) {
        throw new Error("Another account already uses this email.");
      }
      setUsers((current) =>
        current.map((u) => (u.id === sessionId ? { ...u, ...updates, email } : u))
      );
    },
    [users, sessionId, setUsers]
  );

  const value = useMemo(
    () => ({ user, login, register, logout, updateProfile }),
    [user, login, register, logout, updateProfile]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used inside AuthProvider");
  return context;
}
