// Small REST-style data layer. The JSON files in /public/data act as a mock REST API.
const BASE = import.meta.env.BASE_URL;

async function getJson(file) {
  const response = await fetch(`${BASE}data/${file}`);
  if (!response.ok) {
    throw new Error(`Could not load ${file} (status ${response.status})`);
  }
  return response.json();
}

export const fetchJobs = () => getJson("jobs.json");
export const fetchAnnouncements = () => getJson("announcements.json");
export const fetchPlacementStats = () => getJson("placementStats.json");
